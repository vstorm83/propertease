<?php  
$mainURL = $this->baseurl.'/templates/'.$this->template.'/';

$user = JFactory::getUser();
$status = $user->id;

if($status < 1){
	
	include_once("home_public.php");
}
else
{
	include_once("home_logged.php");
} 
 ?>  
 