<?php
class RADSynchronizerOsmembership
{

	public function getData($userId, $config)
	{
		
	}

	public function saveData($userId, $data, $config)
	{
		
	}
}