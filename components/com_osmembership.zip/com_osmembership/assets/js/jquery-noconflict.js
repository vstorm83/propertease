//jQuery.noConflict();
if (typeof(OSM) === 'undefined') {
    var OSM = {};
}
OSM.jQuery = jQuery.noConflict()